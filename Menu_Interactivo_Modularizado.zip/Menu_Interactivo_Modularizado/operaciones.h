#ifndef OPERACIONES_H
#define OPERACIONES_H

#include <Arduino.h>

void operacionSuma();
void operacionResta();
void operacionMultiplicacion();
void operacionDivision();
void operacionContador();

#endif