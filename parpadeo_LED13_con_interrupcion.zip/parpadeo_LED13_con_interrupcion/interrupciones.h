#ifndef INTERRUPCIONES_H
#define INTERRUPCIONES_H

#include <Arduino.h>

extern volatile bool estadoLedExterno;

void configurarInterrupciones();
void cambiarLedExterno();

#endif