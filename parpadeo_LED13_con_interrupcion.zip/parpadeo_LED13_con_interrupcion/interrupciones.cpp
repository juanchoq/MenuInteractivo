#include "interrupciones.h"

volatile bool estadoLedExterno = false;

void configurarInterrupciones() {
  attachInterrupt(digitalPinToInterrupt(3), cambiarLedExterno, RISING);
}

void cambiarLedExterno() {
  estadoLedExterno = !estadoLedExterno;
  digitalWrite(7, estadoLedExterno);
  Serial.println(estadoLedExterno ? "LED ON" : "LED OFF");
}
