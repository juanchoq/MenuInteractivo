# ESP32-CAM-wireless-computer-vision-objects-detection
ESP32 CAM wireless computer vision objects detection.


DETECCION DE OBJETOS CON ESP32 CAM | VISION ARTIFICIAL PYTHON + OpenCV + Yolov3 (TIEMPO REAL)



Se realiza con "coco" que se encuentra en el mismo directorio. En la parte de python se hace referencia en las lineas 13 al 26: donde se realiza la configuración y pesos de YoloV3 con la ayuda del modulo "dnn" de openCV. El archivo coconames contiene los nombres de distintos objetos que se han entrenado para deteccion de objetos... Luego se almacena en "classNames".  y así como "net" se basa en usar librerías para para capas de calculo de salida, cargar y procesar qyue ya fueron implementados y más información se encuentra en Internet.


![image](https://user-images.githubusercontent.com/62358739/115599752-90573200-a2a1-11eb-84f8-86e12ba0e09a.png)
